# -*- coding: utf-8 -*-
# Module: default
# Author: joen, bodems
# Created on: 24.08.2017
# License: MIT
# Modified: Mario Pazmino

import xbmc
import xbmcaddon

# Execute Addon Streama
xbmc.executebuiltin("RunAddon(plugin.video.streama)")
# Open setting Streama
xbmc.sleep(500)
__settings__ = xbmcaddon.Addon(id="plugin.video.streama")
__settings__.openSettings()
